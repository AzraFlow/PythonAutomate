def hello():
  print('Hello!')
  print('Howdy!!!')
  print('Well, hello there.')

hello()
