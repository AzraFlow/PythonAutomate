print('My name is')
for i in range(1, 6, 2):
  print('Jimmy Five Times (' + str(i) + ')')
