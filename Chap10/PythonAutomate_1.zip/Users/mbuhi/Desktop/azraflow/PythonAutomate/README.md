# PythonAutomate
Python refresher via walk through of 'Automate the Boring Stuff' 
